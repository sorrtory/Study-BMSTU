# Head Pose Estimation using OpenCV and Dlib

The repository contains code for the blog post [Head Pose Estimation using OpenCV and Dlib](https://www.learnopencv.com/head-pose-estimation-using-opencv-and-dlib/).

<p align="center"><img src="https://learnopencv.com/wp-content/uploads/2016/09/head-pose-example-768x432.jpg" alt="HeadPose"></p>

[<img src="https://learnopencv.com/wp-content/uploads/2022/07/download-button-e1657285155454.png" alt="download" width="200">](https://www.dropbox.com/scl/fo/zvhgqg84ob7av45gji23s/h?dl=1&rlkey=0telcgg95ufkspetq0tseacmu)

# AI Courses by OpenCV

Want to become an expert in AI? [AI Courses by OpenCV](https://opencv.org/courses/) is a great place to start. 

<a href="https://opencv.org/courses/">
<p align="center"> 
<img src="https://learnopencv.com/wp-content/uploads/2023/01/AI-Courses-By-OpenCV-Github.png">
</p>
</a>
